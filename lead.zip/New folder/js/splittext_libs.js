
//lettering slide

var typed = new Typed(".values-txt", 
    {
        strings: ["PARTNERSHIPS", "UNBEATABLE BRAND", "PROFESSIONALISM", "EFFECTIVE CUSTOMER RELATION", "QUALITY SERVICES"],
        typeSpeed: 250,
        backSpeed: 100,
        backDelay: 1000,
        loop: true
    }
)
